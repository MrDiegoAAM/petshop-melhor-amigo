const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Informações da Empresa */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-xl">🐾</span>
              <h3 className="text-lg font-bold">Melhor Amigo</h3>
            </div>
            <p className="text-sm mb-2">
              Cuidando do seu melhor amigo com amor, carinho
            </p>
            <p className="text-sm mb-2">
              e profissionalismo há mais de 10 anos.
            </p>
            <p className="text-sm">
              Proprietária: Marcia Oliveira Santos
            </p>
          </div>

          {/* Serviços */}
          <div>
            <h3 className="text-lg font-bold mb-4">Serviços</h3>
            <ul className="space-y-2 text-sm">
              <li>Tosa Especializada</li>
              <li>Banho Relaxante</li>
              <li>Ração Premium</li>
              <li>Brinquedos e Acessórios</li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contato</h3>
            <div className="space-y-2 text-sm">
              <p>📍 Rua dos Pets, 123 - Centro</p>
              <p>📞 (61) 3333-4444</p>
              <p>📧 contato@melhoramigo.com.br</p>
              <p>⏰ Seg-Sex: 8h-18h | Sáb: 8h-16h | Dom: 9h-13h</p>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-light mt-8 pt-4 text-center text-sm">
          <p>
            © 2024 Petshop Melhor Amigo. Todos os direitos reservados. | 
            Desenvolvido com 💚 para pets e seus donos
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;