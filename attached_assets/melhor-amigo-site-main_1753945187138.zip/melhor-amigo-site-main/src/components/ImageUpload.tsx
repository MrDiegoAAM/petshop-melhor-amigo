import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImageUploadProps {
  currentImage: string;
  onImageChange: (newImage: string) => void;
  altText?: string;
}

const ImageUpload = ({ currentImage, onImageChange, altText = "Imagem" }: ImageUploadProps) => {
  const [imageUrl, setImageUrl] = useState("");
  const { toast } = useToast();

  const handleUrlSubmit = () => {
    if (imageUrl.trim()) {
      onImageChange(imageUrl.trim());
      setImageUrl("");
      toast({
        title: "Imagem atualizada!",
        description: "A nova imagem foi carregada com sucesso.",
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        onImageChange(result);
        toast({
          title: "Imagem atualizada!",
          description: "A nova imagem foi carregada com sucesso.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-4 p-4 border border-primary rounded-lg bg-secondary/50">
      <div className="flex items-center space-x-2">
        <img 
          src={currentImage} 
          alt={altText}
          className="w-16 h-16 object-cover rounded"
        />
        <div className="flex-1">
          <p className="text-sm font-medium">Imagem Atual</p>
          <p className="text-xs text-muted-foreground truncate">{altText}</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex space-x-2">
          <Input
            placeholder="Cole a URL da nova imagem"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="flex-1"
          />
          <Button onClick={handleUrlSubmit} size="sm">
            Atualizar
          </Button>
        </div>
        
        <div className="text-center text-sm text-muted-foreground">ou</div>
        
        <div className="relative">
          <Input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <Button variant="outline" className="w-full" size="sm">
            <Upload className="w-4 h-4 mr-2" />
            Enviar Arquivo
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ImageUpload;