import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";

interface HeaderProps {
  isAdmin: boolean;
  onAdminClick: () => void;
}

const Header = ({ isAdmin, onAdminClick }: HeaderProps) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-primary text-primary-foreground shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-2xl">🐾</span>
          <h1 className="text-2xl font-bold">Melhor Amigo</h1>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          <Link
            to="/"
            className={`hover:text-primary-light transition-colors ${
              isActive("/") ? "border-b-2 border-primary-foreground" : ""
            }`}
          >
            Início
          </Link>
          <Link
            to="/produtos"
            className={`hover:text-primary-light transition-colors ${
              isActive("/produtos") ? "border-b-2 border-primary-foreground" : ""
            }`}
          >
            Produtos
          </Link>
          <Link
            to="/galeria"
            className={`hover:text-primary-light transition-colors ${
              isActive("/galeria") ? "border-b-2 border-primary-foreground" : ""
            }`}
          >
            Galeria
          </Link>
          <Link
            to="/contato"
            className={`hover:text-primary-light transition-colors ${
              isActive("/contato") ? "border-b-2 border-primary-foreground" : ""
            }`}
          >
            Contato
          </Link>
        </nav>

        <Button
          variant="ghost"
          size="sm"
          onClick={onAdminClick}
          className="text-primary-foreground hover:bg-primary-light"
        >
          <Settings className="h-4 w-4" />
          {isAdmin ? "Sair Admin" : "Admin"}
        </Button>
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden border-t border-primary-light">
        <div className="container mx-auto px-4 py-2 flex justify-around">
          <Link
            to="/"
            className={`text-sm hover:text-primary-light transition-colors ${
              isActive("/") ? "text-primary-light" : ""
            }`}
          >
            Início
          </Link>
          <Link
            to="/produtos"
            className={`text-sm hover:text-primary-light transition-colors ${
              isActive("/produtos") ? "text-primary-light" : ""
            }`}
          >
            Produtos
          </Link>
          <Link
            to="/galeria"
            className={`text-sm hover:text-primary-light transition-colors ${
              isActive("/galeria") ? "text-primary-light" : ""
            }`}
          >
            Galeria
          </Link>
          <Link
            to="/contato"
            className={`text-sm hover:text-primary-light transition-colors ${
              isActive("/contato") ? "text-primary-light" : ""
            }`}
          >
            Contato
          </Link>
        </div>
      </nav>
    </header>
  );
};

export default Header;