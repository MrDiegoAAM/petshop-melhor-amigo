import { useState } from "react";
import ImageUpload from "@/components/ImageUpload";

interface GalleryProps {
  isAdmin: boolean;
}

const Gallery = ({ isAdmin }: GalleryProps) => {
  const [galleryImages, setGalleryImages] = useState([
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=400&h=300&fit=crop",
      title: "Buddy após a tosa",
      description: "Golden Retriever feliz após sessão de tosa especializada"
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=400&h=300&fit=crop",
      title: "Mimi no banho relaxante",
      description: "Gatinha persa aproveitando o banho com produtos premium"
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1472396961693-142e6e269027?w=400&h=300&fit=crop",
      title: "Max brincando",
      description: "Labrador se divertindo com brinquedos interativos"
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1493962853295-0fd70327578a?w=400&h=300&fit=crop",
      title: "Lola na hora da ração",
      description: "Bulldog francês saboreando ração premium"
    },
    {
      id: 5,
      url: "https://images.unsplash.com/photo-1501286353178-1ec881214838?w=400&h=300&fit=crop",
      title: "Simão após cuidados",
      description: "Gato vira-lata feliz após todos os cuidados"
    },
    {
      id: 6,
      url: "https://images.unsplash.com/photo-1452378174528-3090a4bba7b2?w=400&h=300&fit=crop",
      title: "Família canina",
      description: "Múltiplos pets atendidos no mesmo dia"
    }
  ]);

  const updateGalleryImage = (id: number, newUrl: string) => {
    setGalleryImages(prev => 
      prev.map(img => 
        img.id === id ? { ...img, url: newUrl } : img
      )
    );
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Galeria de Fotos
          </h1>
          <p className="text-xl max-w-2xl mx-auto">
            Veja alguns dos nossos clientes especiais que cuidamos com carinho
          </p>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryImages.map((image) => (
              <div 
                key={image.id} 
                className="group relative bg-card rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              >
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={image.url} 
                    alt={image.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 text-card-foreground">{image.title}</h3>
                  <p className="text-muted-foreground">{image.description}</p>
                </div>

                {isAdmin && (
                  <div className="absolute top-2 right-2 w-48 bg-white/90 backdrop-blur-sm rounded-lg">
                    <ImageUpload
                      currentImage={image.url}
                      onImageChange={(newImage) => updateGalleryImage(image.id, newImage)}
                      altText={image.title}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Testimonial Section */}
          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold mb-8 text-foreground">
              O que nossos clientes dizem
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-secondary p-6 rounded-lg">
                <div className="text-4xl mb-4">⭐⭐⭐⭐⭐</div>
                <p className="text-muted-foreground mb-4">
                  "O Buddy ficou lindo após a tosa! A equipe é muito carinhosa e profissional."
                </p>
                <p className="font-semibold text-primary">- Maria Silva</p>
              </div>
              
              <div className="bg-secondary p-6 rounded-lg">
                <div className="text-4xl mb-4">⭐⭐⭐⭐⭐</div>
                <p className="text-muted-foreground mb-4">
                  "Minha gatinha adora vir aqui! O banho deixa ela cheirosa por semanas."
                </p>
                <p className="font-semibold text-primary">- João Santos</p>
              </div>
              
              <div className="bg-secondary p-6 rounded-lg">
                <div className="text-4xl mb-4">⭐⭐⭐⭐⭐</div>
                <p className="text-muted-foreground mb-4">
                  "Produtos de qualidade e atendimento excepcional. Recomendo muito!"
                </p>
                <p className="font-semibold text-primary">- Ana Costa</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;