import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import ImageUpload from "@/components/ImageUpload";
import foodIcon from "@/assets/food-icon.png";
import groomingIcon from "@/assets/grooming-icon.png";
import bathIcon from "@/assets/bath-icon.png";
import heroImage from "@/assets/hero-pets.jpg";

interface HomeProps {
  isAdmin: boolean;
}

const Home = ({ isAdmin }: HomeProps) => {
  const [heroImageSrc, setHeroImageSrc] = useState(heroImage);
  const [serviceImages, setServiceImages] = useState({
    grooming: groomingIcon,
    bath: bathIcon,
    food: foodIcon,
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary to-primary-light text-primary-foreground py-20">
        <div className="absolute inset-0 opacity-10">
          <img 
            src={heroImageSrc} 
            alt="Pets felizes" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Bem-vindo ao Petshop "Melhor Amigo"! 🐾
          </h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Cuidado excepcional e serviços de alta qualidade para seu melhor amigo
          </p>
          <Link to="/produtos">
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg px-8 py-4 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
            >
              Conheça Nossos Produtos
            </Button>
          </Link>
        </div>
        
        {isAdmin && (
          <div className="absolute top-4 right-4 w-64">
            <ImageUpload
              currentImage={heroImageSrc}
              onImageChange={setHeroImageSrc}
              altText="Imagem do Hero"
            />
          </div>
        )}
      </section>

      {/* Services Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">
            Nossos Serviços
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Tosa Especializada */}
            <Card className="text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 relative">
              <CardContent className="p-8">
                {isAdmin && (
                  <div className="absolute top-2 right-2 z-10">
                    <ImageUpload
                      currentImage={serviceImages.grooming}
                      onImageChange={(newImage) => setServiceImages(prev => ({ ...prev, grooming: newImage }))}
                      altText="Ícone Tosa"
                    />
                  </div>
                )}
                <div className="w-20 h-20 mx-auto mb-4 bg-primary rounded-full flex items-center justify-center">
                  <img 
                    src={serviceImages.grooming} 
                    alt="Tosa Especializada" 
                    className="w-12 h-12 object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold mb-4 text-primary">Tosa Especializada</h3>
                <p className="text-muted-foreground mb-6">
                  Serviços profissionais de tosa para cães de todas as raças, com técnicas 
                  avançadas e cuidados especiais.
                </p>
              </CardContent>
            </Card>

            {/* Banho Relaxante */}
            <Card className="text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 relative">
              <CardContent className="p-8">
                {isAdmin && (
                  <div className="absolute top-2 right-2 z-10">
                    <ImageUpload
                      currentImage={serviceImages.bath}
                      onImageChange={(newImage) => setServiceImages(prev => ({ ...prev, bath: newImage }))}
                      altText="Ícone Banho"
                    />
                  </div>
                )}
                <div className="w-20 h-20 mx-auto mb-4 bg-primary rounded-full flex items-center justify-center">
                  <img 
                    src={serviceImages.bath} 
                    alt="Banho Relaxante" 
                    className="w-12 h-12 object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold mb-4 text-primary">Banho Relaxante</h3>
                <p className="text-muted-foreground mb-6">
                  Banhos com produtos de qualidade em ambiente tranquilo e seguro para o 
                  conforto do seu pet.
                </p>
              </CardContent>
            </Card>

            {/* Ração Premium */}
            <Card className="text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 relative">
              <CardContent className="p-8">
                {isAdmin && (
                  <div className="absolute top-2 right-2 z-10">
                    <ImageUpload
                      currentImage={serviceImages.food}
                      onImageChange={(newImage) => setServiceImages(prev => ({ ...prev, food: newImage }))}
                      altText="Ícone Ração"
                    />
                  </div>
                )}
                <div className="w-20 h-20 mx-auto mb-4 bg-primary rounded-full flex items-center justify-center">
                  <img 
                    src={serviceImages.food} 
                    alt="Ração Premium" 
                    className="w-12 h-12 object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold mb-4 text-primary">Ração Premium</h3>
                <p className="text-muted-foreground mb-6">
                  Seleção de rações premium para cães e gatos, com nutrição balanceada para 
                  todas as idades.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-foreground">Sobre Nós</h2>
              <p className="text-muted-foreground mb-4">
                No Petshop "Melhor Amigo", nós entendemos que seu animal de estimação é mais do que apenas um bichinho, é um membro especial da sua família.
              </p>
              <p className="text-muted-foreground mb-4">
                Com uma equipe dedicada e apaixonada por animais, nossos profissionais treinados estão prontos para oferecer os melhores cuidados para o seu pet.
              </p>
              <p className="text-muted-foreground">
                Oferecemos uma ampla variedade de rações de alta qualidade, serviços de tosa profissional e momentos especiais de brincadeiras em nosso espaço dedicado.
              </p>
            </div>
            <div className="bg-primary rounded-lg p-8 text-center text-primary-foreground">
              <div className="text-6xl mb-4">🐕 🐱 💚</div>
              <h3 className="text-2xl font-bold mb-4">13 Funcionários Dedicados</h3>
              <p>Cuidando do seu melhor amigo com amor e profissionalismo há mais de 10 anos</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;