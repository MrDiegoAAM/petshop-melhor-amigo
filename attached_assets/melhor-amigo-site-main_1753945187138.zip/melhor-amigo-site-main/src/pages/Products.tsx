import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ImageUpload from "@/components/ImageUpload";
import foodIcon from "@/assets/food-icon.png";
import groomingIcon from "@/assets/grooming-icon.png";
import bathIcon from "@/assets/bath-icon.png";
import toyIcon from "@/assets/toy-icon.png";

interface ProductsProps {
  isAdmin: boolean;
}

const Products = ({ isAdmin }: ProductsProps) => {
  const [productImages, setProductImages] = useState({
    food: foodIcon,
    grooming: groomingIcon,
    bath: bathIcon,
    toys: toyIcon,
    interactiveToys: toyIcon,
    hygiene: bathIcon,
  });

  const updateProductImage = (key: string, newImage: string) => {
    setProductImages(prev => ({ ...prev, [key]: newImage }));
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Nossos Produtos e Serviços
          </h1>
          <p className="text-xl max-w-2xl mx-auto">
            Tudo que seu melhor amigo precisa em um só lugar
          </p>
        </div>
      </section>

      {/* Alimentação Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">🥗 Alimentação</h2>
            <div className="w-24 h-1 bg-primary mx-auto"></div>
          </div>

          <div className="bg-secondary rounded-lg p-8 mb-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div className="relative">
                <div className="w-32 h-32 mx-auto bg-primary rounded-full flex items-center justify-center">
                  <img 
                    src={productImages.food} 
                    alt="Ração Premium" 
                    className="w-20 h-20 object-contain"
                  />
                </div>
                {isAdmin && (
                  <div className="absolute -top-4 -right-4 w-48">
                    <ImageUpload
                      currentImage={productImages.food}
                      onImageChange={(newImage) => updateProductImage('food', newImage)}
                      altText="Ração Premium"
                    />
                  </div>
                )}
              </div>
              <div>
                <h3 className="text-2xl font-bold text-primary mb-4">Ração Premium</h3>
                <p className="text-muted-foreground mb-6">
                  Rações premium para cães e gatos formuladas com ingredientes de alta qualidade, garantindo nutrição balanceada para diferentes idades, raças e necessidades especiais.
                </p>
                <Button className="w-full md:w-auto">
                  Solicitar Informações
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Serviços de Estética Section */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">✂️ Serviços de Estética</h2>
            <div className="w-24 h-1 bg-primary mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Tosa Especializada */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="relative">
                  <div className="w-24 h-24 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center">
                    <img 
                      src={productImages.grooming} 
                      alt="Tosa Especializada" 
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  {isAdmin && (
                    <div className="absolute -top-4 -right-4 w-48">
                      <ImageUpload
                        currentImage={productImages.grooming}
                        onImageChange={(newImage) => updateProductImage('grooming', newImage)}
                        altText="Tosa Especializada"
                      />
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-primary">Tosa Especializada</h3>
                <p className="text-muted-foreground text-center mb-6">
                  Tratamentos especializados e qualificados utilizando técnicas avançadas. Ideal para cortes personalizados, higiênicos, déguas de estética e corte de unhas.
                </p>
                <Button className="w-full">
                  Agendar Serviço
                </Button>
              </CardContent>
            </Card>

            {/* Banho Relaxante */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="relative">
                  <div className="w-24 h-24 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center">
                    <img 
                      src={productImages.bath} 
                      alt="Banho Relaxante" 
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  {isAdmin && (
                    <div className="absolute -top-4 -right-4 w-48">
                      <ImageUpload
                        currentImage={productImages.bath}
                        onImageChange={(newImage) => updateProductImage('bath', newImage)}
                        altText="Banho Relaxante"
                      />
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-primary">Banho Relaxante</h3>
                <p className="text-muted-foreground text-center mb-6">
                  Banhos com produtos de qualidade em ambiente tranquilo e seguro para o conforto do seu pet. Ambiente tranquilo para uma experiência agradável, deixando e antipulgas águas e limpeza.
                </p>
                <Button className="w-full">
                  Agendar Banho
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Brinquedos e Acessórios Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">🧸 Brinquedos e Acessórios</h2>
            <div className="w-24 h-1 bg-primary mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Brinquedos Interativos */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="relative">
                  <div className="w-24 h-24 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center">
                    <img 
                      src={productImages.interactiveToys} 
                      alt="Brinquedos Interativos" 
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  {isAdmin && (
                    <div className="absolute -top-4 -right-4 w-48">
                      <ImageUpload
                        currentImage={productImages.interactiveToys}
                        onImageChange={(newImage) => updateProductImage('interactiveToys', newImage)}
                        altText="Brinquedos Interativos"
                      />
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-primary">Brinquedos Interativos</h3>
                <p className="text-muted-foreground text-center mb-6">
                  Variedade de brinquedos que estimulam a mente e o corpo do seu pet. Ideais para cães e gatos de todos os tamanhos para divertir e manter seu melhor amigo sempre ativo e feliz.
                </p>
                <Button className="w-full">
                  Ver Catálogo
                </Button>
              </CardContent>
            </Card>

            {/* Produtos de Higiene */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="relative">
                  <div className="w-24 h-24 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center">
                    <img 
                      src={productImages.hygiene} 
                      alt="Produtos de Higiene" 
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  {isAdmin && (
                    <div className="absolute -top-4 -right-4 w-48">
                      <ImageUpload
                        currentImage={productImages.hygiene}
                        onImageChange={(newImage) => updateProductImage('hygiene', newImage)}
                        altText="Produtos de Higiene"
                      />
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-primary">Produtos de Higiene</h3>
                <p className="text-muted-foreground text-center mb-6">
                  Shampoos, condicionadores, loções, perfumes e produtos de limpeza e desinfecção. Mantendo sempre limpeza especial e desenvolvimento. Apostar e vide e comercializam excelentes.
                </p>
                <Button className="w-full">
                  Comprar Agora
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;